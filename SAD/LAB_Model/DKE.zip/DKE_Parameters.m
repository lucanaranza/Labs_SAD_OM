clear; clc;
%% Task 1 Orbit parameters and environment
r_sun = 1.496 * 10^11; % [m]
mu_E = 3.986 * 10^14; % [m^3/s^2]
theta0 = deg2rad(90);
i = deg2rad(45); %inclination
e = 0.01;
T = 365.25 * 24 * 3600; % [s] Sun year
n_s = 2*pi/T; % for sun
epsilon = deg2rad(23.45); % [rad]
Mt = 5.97 * 10^24; % [kg]
G = 6.67 * 10^-11; % [m^3/(kg*s^2)]
a = 8000e3; % [m]
n = sqrt(mu_E/a^3);
Tf = 2*pi*sqrt(a^3/mu_E);

%% Task 2 and 3 Gravity gradient and SRP
I_depl = diag([22.53 , 26.71, 33.03] * 10^-2); % [Kg*m^2]
Ix = 22.53 * 10^-2;
Iy = 26.71 * 10^-2;
Iz = 33.03 * 10^-2;
omega = [0.02; 0.05; 0.08];
A0 = eye(3);
c = 3 * 10^8; % [m/s]
Fe = 1358; % [W/m^2]
P = Fe/c;
NB1  = [0; +1; 0];
NB2  = [0; 0; +1];
NB3  = [0; -1; 0];
NB4  = [0; 0; -1];
NB5  = [+1; 0; 0];
NB6  = [-1; 0; 0];
Panel1  = [0; 0; +1];
Panel2  = [0; 0; -1];
Panel3  = [0; 0; +1];
Panel4  = [0; 0; -1];
rho_d = 0.1;   
rho_s_body  = 0.5;   
rho_s_panel = 0.1;   
rF1  = [0; +0.1132; 0]; % [m]
rF2  = [0; 0; +0.1132];
rF3  = [0; -0.1132; 0];
rF4  = [0; 0; -0.1132];
rF5  = [+0.1703; 0; 0];
rF6  = [-0.1703; 0; 0];
rF7  = [0; +0.2382; 0];
rF8  = [0; +0.2382; 0];
rF9  = [0; -0.2382; 0];
rF10 = [0; -0.2382; 0];
A_body1_4 = 7.7*10^-2;
A_body5_6 = 5.1*10^-2;
A_panel = 4.25*10^-2;
r_CM = [0; 0; 0.15]; % [m]

%% Task 4: Earth Magnetic field
g10 = -29404.8 * 1e-9; % [T]
g11 = -1450.9 * 1e-9;  
h11 = 4652.5 * 1e-9;   
H0 = sqrt(g10^2 + g11^2 + h11^2);
R_E = 6371000; %Earth radius [m]
omega_E = 2 * pi / 86400; 
tilt_mag = deg2rad(11.5);
j_B = [0.01; 0.05; 0.01]; %Residual satellite dipole

%% Task 5: Run simulation and plots
out = sim('DKE', 'Solver', 'ode4', 'FixedStep', '1e-2', 'StopTime', 'Tf');

%Data extraction
t = out.t;
M_srp = out.M_srp;
M_mag = out.M_mag;
M_gg  = out.M_gg;
r_N   = out.r_N; 

%Plot 1: Perturbation comparisons (logarithmic scale)
figure('Name', 'Disturbances comparison', 'Color', 'w');
semilogy(t, vecnorm(M_mag, 2, 2), 'r', 'LineWidth', 1.5); hold on;
semilogy(t, vecnorm(M_gg,  2, 2), 'b', 'LineWidth', 1.5);
semilogy(t, vecnorm(M_srp, 2, 2), 'g', 'LineWidth', 1.5);
grid on; xlabel('Time [s]'); ylabel('Torque Magnitude [Nm]');
legend('M_{mag}', 'M_{GG}', 'M_{SRP}', 'Location', 'best');
title('Perturbation torques magnitude');
ylim([1e-12, 1e-5]);

%Plot 2: Earth 3D orbit
figure('Name', '3D Orbit', 'Color', 'w');
R_earth = 6371e3; % [m]
[X, Y, Z] = sphere(40);
surf(X*R_earth, Y*R_earth, Z*R_earth, 'FaceColor', [0.2 0.5 0.8], 'EdgeColor', 'none', 'FaceAlpha', 0.6);
hold on; plot3(r_N(:,1), r_N(:,2), r_N(:,3), 'k', 'LineWidth', 2);
axis equal; grid on; view(45, 30);
xlabel('X_N'); ylabel('Y_N'); zlabel('Z_N');
title('Satellite Orbit 3D');